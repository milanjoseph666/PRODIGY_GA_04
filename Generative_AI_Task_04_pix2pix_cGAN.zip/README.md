
# Task-04: Image-to-Image Translation with cGAN (pix2pix)

## Objective:
Implement an image-to-image translation model using a conditional generative adversarial network (cGAN) called pix2pix.

## Requirements:
- Python 3.7+
- PyTorch or TensorFlow
- torchvision or tf.keras for dataset
- numpy, matplotlib

## How to Run:
1. Install the dependencies using `pip install -r requirements.txt`
2. Run `python train.py` to train the model.
3. Use `python test.py` to generate translated images.

## References:
- https://phillipi.github.io/pix2pix/
- https://github.com/junyanz/pytorch-CycleGAN-and-pix2pix
